package com.octavian.configuration.myevent;

import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.model.property.InputEventListenerProperty;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.InteractiveView;
import com.gwtent.reflection.client.Reflectable;
import com.atsisa.gox.framework.action.*;


@XmlElement
@Reflectable
public class CustomInteractiveView extends InteractiveView {

    @XmlAttribute(type = IEventListener.class, name = "onMouseUpDown")
    private final InputEventListenerProperty mouseUpDownListener = new InputEventListenerProperty(this, InputEventType.MOUSE_UP, InputEventType.MOUSE_UP);
    public void setMouseUpDownListener(IEventListener listener) {
        this.mouseUpDownListener.set(listener);
    }
}
