package com.octavian.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.reels.logic.AbstractGameLogicMockup;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.PayTableItem;
import com.atsisa.gox.reels.logic.model.Reel;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.logic.model.WinLineInfo;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;
import com.google.inject.Inject;

/**
 * Represents a mockup of game logic - only for testing purposes.
 */
public class NewReelsGameFHDLogicMockup extends AbstractGameLogicMockup {

    /**
     * Initializes a new instance of the {@link NewReelsGameFHDLogicMockup} class.
     * @param localization {@link ILocalization}
     */
    @Inject
    public NewReelsGameFHDLogicMockup(ILocalization localization) {
        super(localization);
    }

    @Override
    protected BigDecimal getStartBetAmount() {
        return new BigDecimal(5);
    }

    @Override
    protected int getMaxLinesAmount() {
        return 9;
    }

    @Override
    protected GameConfiguration getGameConfiguration() {
        List<Integer> lines = new ArrayList<>();
        lines.add(1);
        lines.add(3);
        lines.add(5);
        lines.add(7);
        lines.add(9);

        List<BigDecimal> betPerLines = new ArrayList<>();
        betPerLines.add(BigDecimal.valueOf(1));
        betPerLines.add(BigDecimal.valueOf(5));
        betPerLines.add(BigDecimal.valueOf(10));
        betPerLines.add(BigDecimal.valueOf(15));
        betPerLines.add(BigDecimal.valueOf(20));
        betPerLines.add(BigDecimal.valueOf(25));
        betPerLines.add(BigDecimal.valueOf(30));
        betPerLines.add(BigDecimal.valueOf(35));
        betPerLines.add(BigDecimal.valueOf(40));
        betPerLines.add(BigDecimal.valueOf(45));
        betPerLines.add(BigDecimal.valueOf(50));

        List<PayTableItem> payTable = new ArrayList<>();
        payTable.add(new PayTableItem("SYMBOL7_X_5", BigDecimal.valueOf(1000), "Line"));
        payTable.add(new PayTableItem("SYMBOL7_X_4", BigDecimal.valueOf(500), "Line"));
        payTable.add(new PayTableItem("SYMBOL7_X_3", BigDecimal.valueOf(250), "Line"));
        payTable.add(new PayTableItem("SYMBOL6_X_5", BigDecimal.valueOf(800), "Line"));
        payTable.add(new PayTableItem("SYMBOL6_X_4", BigDecimal.valueOf(400), "Line"));
        payTable.add(new PayTableItem("SYMBOL6_X_3", BigDecimal.valueOf(200), "Line"));
        payTable.add(new PayTableItem("SYMBOL5_X_5", BigDecimal.valueOf(600), "Line"));
        payTable.add(new PayTableItem("SYMBOL5_X_4", BigDecimal.valueOf(300), "Line"));
        payTable.add(new PayTableItem("SYMBOL5_X_3", BigDecimal.valueOf(150), "Line"));
        payTable.add(new PayTableItem("SYMBOL4_X_5", BigDecimal.valueOf(400), "Line"));
        payTable.add(new PayTableItem("SYMBOL4_X_4", BigDecimal.valueOf(200), "Line"));
        payTable.add(new PayTableItem("SYMBOL4_X_3", BigDecimal.valueOf(100), "Line"));
        payTable.add(new PayTableItem("SYMBOL3_X_5", BigDecimal.valueOf(200), "Line"));
        payTable.add(new PayTableItem("SYMBOL3_X_4", BigDecimal.valueOf(100), "Line"));
        payTable.add(new PayTableItem("SYMBOL3_X_3", BigDecimal.valueOf(50), "Line"));
        payTable.add(new PayTableItem("SYMBOL2_X_5", BigDecimal.valueOf(100), "Line"));
        payTable.add(new PayTableItem("SYMBOL2_X_4", BigDecimal.valueOf(50), "Line"));
        payTable.add(new PayTableItem("SYMBOL2_X_3", BigDecimal.valueOf(25), "Line"));
        payTable.add(new PayTableItem("SYMBOL1_X_5", BigDecimal.valueOf(50), "Line"));
        payTable.add(new PayTableItem("SYMBOL1_X_4", BigDecimal.valueOf(25), "Line"));
        payTable.add(new PayTableItem("SYMBOL1_X_3", BigDecimal.valueOf(10), "Line"));

        Map<Integer, String> symbolsMap = new HashMap<>();
        symbolsMap.put(0, "Symbol1");
        symbolsMap.put(1, "Symbol2");
        symbolsMap.put(2, "Symbol3");
        symbolsMap.put(3, "Symbol4");
        symbolsMap.put(4, "Symbol5");
        symbolsMap.put(5, "Symbol6");
        symbolsMap.put(6, "Symbol7");

        return new GameConfiguration(lines, betPerLines, BigDecimal.valueOf(50), BigDecimal.valueOf(100000), 5, BigDecimal.valueOf(100000), payTable, "FUN",
        "92.04", symbolsMap);
    }

    @Override
    protected List<LogicPresentation> getWinningPresentations(String presentationName) {
        List<LogicPresentation> presentations = new ArrayList<>();
        presentations.add(new WinningPresentation(presentationName, BigDecimal.valueOf(60), getWinningLines(), false, false));
        presentations.add(new ReelGamePresentation(presentationName, getGameplayProperties(), getWinningReels(), false, false));
        return presentations;
    }

    @Override
    protected ReelGamePresentation getLosePresentation(String presentationName) {
        return getReelGamePresentation(presentationName, getLoosingReels());
    }

    @Override
    protected List<Reel> getStartReels() {
        List<Integer> positions0 = new ArrayList<>();
        positions0.add(2);
        positions0.add(2);
        positions0.add(2);
        List<Integer> positions1 = new ArrayList<>();
        positions1.add(5);
        positions1.add(1);
        positions1.add(5);
        List<Integer> positions2 = new ArrayList<>();
        positions2.add(4);
        positions2.add(4);
        positions2.add(1);
        List<Integer> positions3 = new ArrayList<>();
        positions3.add(3);
        positions3.add(4);
        positions3.add(2);
        List<Integer> positions4 = new ArrayList<>();
        positions4.add(0);
        positions4.add(2);
        positions4.add(6);
        List<Reel> reels = new ArrayList<>();
        reels.add(new Reel("ReelStop0", positions0));
        reels.add(new Reel("ReelStop1", positions1));
        reels.add(new Reel("ReelStop2", positions2));
        reels.add(new Reel("ReelStop3", positions3));
        reels.add(new Reel("ReelStop4", positions4));
        return reels;
    }

    /**
     * Gets the winning lines combination.
     * @return the winning lines
     */
    private List<IWinLineInfo> getWinningLines() {
        List<Integer> winPositions0 = new ArrayList<>();
        winPositions0.add(1);
        winPositions0.add(1);
        winPositions0.add(1);
        winPositions0.add(1);
        winPositions0.add(-1);
        List<Integer> winPositions1 = new ArrayList<>();
        winPositions1.add(2);
        winPositions1.add(1);
        winPositions1.add(0);
        winPositions1.add(1);
        winPositions1.add(2);
        List<Integer> winPositions2 = new ArrayList<>();
        winPositions2.add(2);
        winPositions2.add(2);
        winPositions2.add(1);
        winPositions2.add(-1);
        winPositions2.add(-1);
        List<IWinLineInfo> winningLines = new ArrayList<>();
        winningLines.add(new WinLineInfo(1, "WinCount0", "Short", BigDecimal.valueOf(30), winPositions0));
        if (getLinesAmount() >= 5) {
        winningLines.add(new WinLineInfo(5, "WinCount1", "Short", BigDecimal.valueOf(10), winPositions1));
        }
        if (getLinesAmount() >= 8) {
        winningLines.add(new WinLineInfo(8, "WinCount2", "Short", BigDecimal.valueOf(20), winPositions2));
        }
        return winningLines;
    }

    /**
     * Gets the winning reels combination.
     * @return the winning reels combination
     */
    private List<Reel> getWinningReels() {
        List<Integer> positions0 = new ArrayList<>();
        positions0.add(1);
        positions0.add(4);
        positions0.add(4);
        List<Integer> positions1 = new ArrayList<>();
        positions1.add(2);
        positions1.add(4);
        positions1.add(4);
        List<Integer> positions2 = new ArrayList<>();
        positions2.add(4);
        positions2.add(4);
        positions2.add(3);
        List<Integer> positions3 = new ArrayList<>();
        positions3.add(1);
        positions3.add(4);
        positions3.add(6);
        List<Integer> positions4 = new ArrayList<>();
        positions4.add(1);
        positions4.add(0);
        positions4.add(4);
        List<Reel> reels = new ArrayList<>();
        reels.add(new Reel("ReelStop0", positions0));
        reels.add(new Reel("ReelStop1", positions1));
        reels.add(new Reel("ReelStop2", positions2));
        reels.add(new Reel("ReelStop3", positions3));
        reels.add(new Reel("ReelStop4", positions4));
        return reels;
    }

    /**
     * Gets the losing reels combination.
     * @return the losing reels combination
     */
    private List<Reel> getLoosingReels() {
        List<Integer> positions0 = new ArrayList<>();
        positions0.add(0);
        positions0.add(2);
        positions0.add(2);
        List<Integer> positions1 = new ArrayList<>();
        positions1.add(0);
        positions1.add(1);
        positions1.add(5);
        List<Integer> positions2 = new ArrayList<>();
        positions2.add(4);
        positions2.add(4);
        positions2.add(1);
        List<Integer> positions3 = new ArrayList<>();
        positions3.add(5);
        positions3.add(5);
        positions3.add(5);
        List<Integer> positions4 = new ArrayList<>();
        positions4.add(5);
        positions4.add(5);
        positions4.add(5);
        List<Reel> reels = new ArrayList<>();
        reels.add(new Reel("ReelStop0", positions0));
        reels.add(new Reel("ReelStop1", positions1));
        reels.add(new Reel("ReelStop2", positions2));
        reels.add(new Reel("ReelStop3", positions3));
        reels.add(new Reel("ReelStop4", positions4));
        return reels;
    }
}
