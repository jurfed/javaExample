package com.octavian.configuration;

import com.atsisa.gox.framework.configuration.GameConfiguration;

public class NewReelsGameFHDConfiguration extends GameConfiguration {

    public NewReelsGameFHDConfiguration() {
        setResourcePath("NewReelsGameFHD/");
        setupWindowSize();
        setWindowDecorated(true);
        setGameName("NewReelsGameFHD");
    }

    private void setupWindowSize() {
    setWidth(1920);
        setHeight(1080);
    }
    
    
}
