package com.octavian;

import com.atsisa.gox.reels.ReelGameComponents;
import com.google.inject.Inject;
import com.atsisa.gox.reels.AbstractReelGame;

public class NewReelsGameFHD extends AbstractReelGame {

    /**
     * Initializes a new instance of the {@link NewReelsGameFHD} class.
     * @param reelGameComponents {@link ReelGameComponents}
     */
    @Inject
    public NewReelsGameFHD(ReelGameComponents reelGameComponents) {
        super(reelGameComponents);
    }

}
