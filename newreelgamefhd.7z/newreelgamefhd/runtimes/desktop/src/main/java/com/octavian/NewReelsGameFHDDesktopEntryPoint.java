package com.octavian;

import com.atsisa.gox.framework.FrameworkCoreModule;
import com.atsisa.gox.framework.FrameworkDesktopModule;
import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.inject.AggregatedModule;
import com.atsisa.gox.inject.IModule;
import com.atsisa.gox.reels.ReelsCoreModule;

public class NewReelsGameFHDDesktopEntryPoint extends JavaGameEntryPoint {

    public static void main(String[] args) throws Exception {
        new NewReelsGameFHDDesktopEntryPoint().start();
    }

    @Override
    protected IModule getModule() {
        return new AggregatedModule(
        new FrameworkCoreModule(),
        new FrameworkDesktopModule(),
        new ReelsCoreModule(),
        new NewReelsGameFHDCoreModule());
    }
}
