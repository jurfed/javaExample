package com.octavian;

import com.atsisa.gox.framework.HtmlGameEntryPoint;

public class NewReelsGameFHDWebEntryPoint extends HtmlGameEntryPoint {

    private static final String GAME_NAME = "NewReelsGameFHD";

    @Override
    protected String getGameName() {
        return GAME_NAME;
    }

}
