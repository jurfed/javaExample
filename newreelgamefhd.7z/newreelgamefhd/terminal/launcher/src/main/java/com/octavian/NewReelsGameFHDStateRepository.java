package com.octavian;

import com.atsisa.gox.logic.GameState;
import com.atsisa.gox.logic.IGameStateRepository;
import com.atsisa.gox.logic.RepositoryConstants;
import com.atsisa.gox.logic.model.ReelsPresentation;

public class NewReelsGameFHDStateRepository implements IGameStateRepository {

    private GameState gameState = new GameState(ReelsPresentation.GAME_START, NewReelsGameFHDConstants.REELS_GAME_INIT, RepositoryConstants.GAMBLER_INIT, RepositoryConstants.BANK_INIT);

    @Override
    public GameState getState() {
        return gameState;
    }

    @Override
    public void save(GameState gameState) {
        this.gameState = gameState;
    }

    @Override
    public void reset() {
        gameState.setPresentation(ReelsPresentation.GAME_START);
        gameState.setBank(RepositoryConstants.BANK_INIT);
        gameState.setReelsGame(NewReelsGameFHDConstants.REELS_GAME_INIT);
    }
}