package com.octavian;

import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.inject.AggregatedModule;
import com.atsisa.gox.inject.IModule;
import com.atsisa.gox.terminal.financial.IBalance;
import com.atsisa.gox.terminal.financial.IFinancialTransaction;
import com.atsisa.gox.terminal.launcher.GameIdentity;
import com.atsisa.gox.terminal.launcher.ReelsGameLauncher;
import com.google.inject.Inject;

public class NewReelsGameFHDLauncher extends ReelsGameLauncher {

    /**
     * The game identity.
     */
    private final GameIdentity gameIdentity = new GameIdentity("NewReelsGameFHD", 1);

    @Inject
    public NewReelsGameFHDLauncher(IBalance balance, IFinancialTransaction financialTransaction) {
        super(balance, financialTransaction);
    }

    @Override
    protected JavaGameEntryPoint createGame(IModule module) {
        return new NewReelsGameFHDDesktopEntryPoint(){
            @Override
            protected IModule getModule() {
                return new AggregatedModule(super.getModule(), new NewReelsGameFHDLauncherModule(), module);
            }
        };
    }

    @Override
    public GameIdentity getIdentity() {
        return gameIdentity;
    }
}