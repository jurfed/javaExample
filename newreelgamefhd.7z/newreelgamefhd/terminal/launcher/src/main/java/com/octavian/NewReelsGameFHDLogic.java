package com.octavian;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.logic.GoxGameLogicAdapter;
import com.atsisa.gox.logic.IGameStateStore;
import com.atsisa.gox.logic.ReelsGameLogic;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.PayTableItem;
import com.atsisa.gox.terminal.financial.IBalance;
import com.google.inject.Inject;

public class NewReelsGameFHDLogic extends GoxGameLogicAdapter {

    @Inject
    public NewReelsGameFHDLogic(ILocalization localization, IBalance balance, ReelsGameLogic gameLogic, IGameStateStore stateStore) {
        super(localization, balance, gameLogic, stateStore);
    }

    @Override
    protected BigDecimal getStartBetAmount() {
        return new BigDecimal(5);
    }

    @Override
    protected int getMaxLinesAmount() {
        return 9;
    }

    @Override
    protected GameConfiguration getGameConfiguration() {
        List<Integer> lines = new ArrayList<>();
        lines.add(1);
        lines.add(3);
        lines.add(5);
        lines.add(7);
        lines.add(9);

        List<BigDecimal> betPerLines = new ArrayList<>();
        betPerLines.add(BigDecimal.valueOf(1));
        betPerLines.add(BigDecimal.valueOf(5));
        betPerLines.add(BigDecimal.valueOf(10));
        betPerLines.add(BigDecimal.valueOf(15));
        betPerLines.add(BigDecimal.valueOf(20));
        betPerLines.add(BigDecimal.valueOf(25));
        betPerLines.add(BigDecimal.valueOf(30));
        betPerLines.add(BigDecimal.valueOf(35));
        betPerLines.add(BigDecimal.valueOf(40));
        betPerLines.add(BigDecimal.valueOf(45));
        betPerLines.add(BigDecimal.valueOf(50));

        List<PayTableItem> payTable = new ArrayList<>();
        payTable.add(new PayTableItem("SYMBOL7_X_5", BigDecimal.valueOf(1000), "Line"));
        payTable.add(new PayTableItem("SYMBOL7_X_4", BigDecimal.valueOf(500), "Line"));
        payTable.add(new PayTableItem("SYMBOL7_X_3", BigDecimal.valueOf(250), "Line"));
        payTable.add(new PayTableItem("SYMBOL6_X_5", BigDecimal.valueOf(800), "Line"));
        payTable.add(new PayTableItem("SYMBOL6_X_4", BigDecimal.valueOf(400), "Line"));
        payTable.add(new PayTableItem("SYMBOL6_X_3", BigDecimal.valueOf(200), "Line"));
        payTable.add(new PayTableItem("SYMBOL5_X_5", BigDecimal.valueOf(600), "Line"));
        payTable.add(new PayTableItem("SYMBOL5_X_4", BigDecimal.valueOf(300), "Line"));
        payTable.add(new PayTableItem("SYMBOL5_X_3", BigDecimal.valueOf(150), "Line"));
        payTable.add(new PayTableItem("SYMBOL4_X_5", BigDecimal.valueOf(400), "Line"));
        payTable.add(new PayTableItem("SYMBOL4_X_4", BigDecimal.valueOf(200), "Line"));
        payTable.add(new PayTableItem("SYMBOL4_X_3", BigDecimal.valueOf(100), "Line"));
        payTable.add(new PayTableItem("SYMBOL3_X_5", BigDecimal.valueOf(200), "Line"));
        payTable.add(new PayTableItem("SYMBOL3_X_4", BigDecimal.valueOf(100), "Line"));
        payTable.add(new PayTableItem("SYMBOL3_X_3", BigDecimal.valueOf(50), "Line"));
        payTable.add(new PayTableItem("SYMBOL2_X_5", BigDecimal.valueOf(100), "Line"));
        payTable.add(new PayTableItem("SYMBOL2_X_4", BigDecimal.valueOf(50), "Line"));
        payTable.add(new PayTableItem("SYMBOL2_X_3", BigDecimal.valueOf(25), "Line"));
        payTable.add(new PayTableItem("SYMBOL1_X_5", BigDecimal.valueOf(50), "Line"));
        payTable.add(new PayTableItem("SYMBOL1_X_4", BigDecimal.valueOf(25), "Line"));
        payTable.add(new PayTableItem("SYMBOL1_X_3", BigDecimal.valueOf(10), "Line"));

        Map<Integer, String> symbolsMap = new HashMap<>();
        symbolsMap.put(0, "Symbol1");
        symbolsMap.put(1, "Symbol2");
        symbolsMap.put(2, "Symbol3");
        symbolsMap.put(3, "Symbol4");
        symbolsMap.put(4, "Symbol5");
        symbolsMap.put(5, "Symbol6");
        symbolsMap.put(6, "Symbol7");

        return new GameConfiguration(lines, betPerLines, BigDecimal.valueOf(50), BigDecimal.valueOf(100000), 5, BigDecimal.valueOf(100000), payTable, "FUN",
                "92.04", symbolsMap);
    }
}