package com.juriy.configuration;

import com.atsisa.gox.framework.configuration.GameConfiguration;

public class MyGameClassConfiguration extends GameConfiguration {

    public MyGameClassConfiguration() {
        setResourcePath("MyGameClass/");
        setWidth(800);
        setHeight(600);
        setWindowDecorated(true);
        setGameName("new game 2017");
    }
}
