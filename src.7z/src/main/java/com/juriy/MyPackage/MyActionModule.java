package com.juriy.MyPackage;

import com.atsisa.gox.framework.action.AbstractActionModule;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class MyActionModule extends AbstractActionModule {

    public String getXmlNamespace() {
        return "http://atsisa.com/examples";
    }
    protected void register() {
        this.registerAction(MyAction.class);
    }
}