/*
package com.juriy.MyPackage;

import com.atsisa.gox.framework.event.IEvent;

public class ImageChangedEvent implements IEvent {

    private CustomInteractiveView source;
    private IImageResource image;

    public ImageChangedEvent(CustomInteractiveView source, IImageResource image) {
        this.source = source;
        this.image = image;
    }

    public IImageResource getImage() {
        return this.image;
    }

    public CustomInteractiveView getSource() {
        return this.source;
    }
}*/
