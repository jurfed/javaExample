package com.juriy.MyPackage;

import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.view.ButtonView;

public class ButtonViewReleasedListener implements IEventListener<InputEvent> {
    private ButtonView bv;

    public ButtonViewReleasedListener(ButtonView bv) {
        this.bv = bv;
    }

    @Override
    public void onEvent(InputEvent event) {
        if (event.getType() == InputEventType.MOUSE_OVER ||event.getType() == InputEventType.RELEASED ) {
            System.err.println("!!! in event !!!");
            bv.setX(bv.getX() + 20);
        }
        if (bv.getX() > 600) {
            bv.setX(100);
            bv.setY(bv.getY() + 50);
        }
    }
}