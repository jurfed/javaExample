package com.juriy.MyPackage;


import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.exception.ValidationException;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class MyAction extends Action<MyActionData> {
    protected void execute() {
        for (int i = 1; i <= this.actionData.getTimes(); i++) {
            GameEngine.current().getLogger().debug("This is the %s. time", i);
        }
    }

    @Override
    public Class<MyActionData> getActionDataType() {
        return MyActionData.class;
    }

/*    @Override
    protected boolean validate() {
        GameEngine.current().getLogger().debug("Custom validation");
        return (this.actionData.getTimes() > 0);
    }*/

    @Override
    protected void validate() throws ValidationException {
        if (this.actionData.getTimes() <= 0) {
            try {
                throw new Exception("Time is not valid");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void reset() {
        GameEngine.current().getLogger().debug("Custom reset");
    }

}
