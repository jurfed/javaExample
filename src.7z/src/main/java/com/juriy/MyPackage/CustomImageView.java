package com.juriy.MyPackage;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.resource.AbstractImageResource;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.ImageView;
import com.gwtent.reflection.client.Reflectable;


//custom views
@XmlElement
@Reflectable
public class CustomImageView extends ImageView {

    @XmlAttribute(type = Float.class, name = "custom")
    private final ObservableProperty<Float> customProperty = new ObservableProperty<Float>(Float.class, 0f);

    public float getCustomProperty() {
        return this.customProperty.get();
    }

    public void setCustomProperty(float value) {
        this.customProperty.set(value);
    }

    public IObservableProperty<Float> customProperty() {
        return this.customProperty;
    }

    public CustomImageView() {
        super();
     //   IImageResource defaultImage = GameEngine.current().getResourceManager().getResource("defaultImage");
      //  this.setImageResource(defaultImage);
    }
}

