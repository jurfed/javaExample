/*
package com.juriy.MyPackage;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.InteractiveView;
import com.gwtent.reflection.client.Reflectable;

@XmlElement
@Reflectable
public class CustomInteractiveView extends InteractiveView {

    public IImageResource getCustomImage() {
        return this.customImage.get();
    }

    public void setCustomImage(IImageResource customImage) {
        if (this.customImage.set(customImage)) {
            this.triggerEvent(new ImageChangedEvent(this, customImage));
        }
    }

    public IObservableProperty<IImageResource> customImage() {
        return this.customImage;
    }
}*/
