package com.juriy.MyPackage;

import com.atsisa.gox.framework.view.AbstractViewModule;

//custom views
public class CustomViewModule extends AbstractViewModule {
    @Override
    public String getXmlNamespace() {
        return "http://www.atsisa.com/examples";
    }
    @Override
    protected void register() {
        this.registerView(CustomImageView.class);
    }
}
