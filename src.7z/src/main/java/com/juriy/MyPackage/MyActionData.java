package com.juriy.MyPackage;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class MyActionData extends ActionData {
    @XmlAttribute
    private int times;
    public int getTimes() {
        return times;
    }
    public void setTimes(int times) {
        this.times = times;
    }
}
