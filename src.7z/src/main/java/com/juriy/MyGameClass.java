package com.juriy;

import com.atsisa.gox.framework.AbstractGame;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.*;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.infrastructure.ISkinManager;
import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.XmlResource;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.view.ButtonView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.google.gwt.resources.client.TextResource;
import com.juriy.MyPackage.ButtonViewReleasedListener;
import com.juriy.MyPackage.MyAction;
import com.juriy.MyPackage.MyActionModule;

import java.util.ArrayList;
import java.util.List;

public class MyGameClass extends AbstractGame {
    private View view;//my
    ButtonView buttonView;//
    @Override
    public void onReady() {//m

        //public void onStart() {
        //public void onCreate() {

//создание экземпляра макета и вызов его отображения
        //getEngine().getViewManager().getScreenById("mainscreen").show();//вариант 1
        // getEngine().getViewManager().addLayout("sampleLayoutRes");//m вариант 2

//        IViewManager viewManager = GameEngine.current().getViewManager();//вариант 3
//        viewManager.addLayout("sampleLayoutRes");

//добавление своего макета
        IViewManager viewManager = GameEngine.current().getViewManager();
        viewManager.addLayout("sampleLayoutRes2");
        //buttonView = new ButtonView();
        //определение кнопки
         buttonView = (ButtonView) viewManager.findViewById("sampleLayoutRes2", "myButton");

//custom views
        //GameEngine.current().getViewManager().getViewBuilder().registerModule(new CustomViewModule());
        addListener();
       // triggerEvents();
        IActionManager actionManager = GameEngine.current().getActionManager();
        actionManager.getActionBuilder().registerModule(new MyActionModule());
        try {
            actionManager.registerActionResource("myActionQueue");
        }catch(Exception r){
            r.printStackTrace();
            System.err.println(r);
        }
        actionManager.processQueue("MyQueue");
    }

    void addListener(){
        ButtonViewReleasedListener listener = new ButtonViewReleasedListener(buttonView);
        buttonView.addEventListener(listener);

    }

/*    void triggerEvents(){
        InputEvent overEvent = new InputEvent(InputEventType.MOUSE_OVER, buttonView);
        InputEvent downEvent = new InputEvent(InputEventType.TOUCH_START, buttonView);
        InputEvent upEvent = new InputEvent(InputEventType.MOUSE_UP, buttonView);

        buttonView.triggerEvent(overEvent);
        buttonView.triggerEvent(downEvent);
        buttonView.triggerEvent(upEvent);
    }*/

}
