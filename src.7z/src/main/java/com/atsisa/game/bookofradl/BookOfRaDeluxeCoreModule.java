package com.atsisa.game.bookofradl;

import com.atsisa.game.bookofradl.logic.vocs.DebugBookOfRaDeluxeGameLogic;
import com.atsisa.game.bookofradl.message.processing.BookOfRaFreeGamesMessageProcessor;
import com.atsisa.game.bookofradl.provider.BookOfRaDeluxeGameConfigurationProvider;
import com.atsisa.game.bookofradl.screen.BookOfRaDeluxeBottomPanelScreen;
import com.atsisa.game.bookofradl.screen.BookOfRaDeluxeEnterFeatureBannerScreen;
import com.atsisa.game.bookofradl.screen.BookOfRaDeluxeFreeGamesBannerScreen;
import com.atsisa.game.bookofradl.screen.BookOfRaDeluxeGamblerScreen;
import com.atsisa.game.bookofradl.screen.BookOfRaDeluxeInfoScreen;
import com.atsisa.game.bookofradl.screen.BookOfRaDeluxePayTableScreen;
import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxeFeatureScreenModel;
import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxeFreeGamesInfoBannerScreenModel;
import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxePayTableScreenModel;
import com.atsisa.gox.framework.AbstractGame;
import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.inject.AbstractModule;
import com.atsisa.gox.reels.AbstractReelGameComponents;
import com.atsisa.gox.reels.DebugBaseReelGameComponents;
import com.atsisa.gox.reels.ExtendedSymbolComponents;
import com.atsisa.gox.reels.ExtendedSymbolPresentationStates;
import com.atsisa.gox.reels.FreeGamesPresentationStates;
import com.atsisa.gox.reels.IReelsPresentationStates;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.reels.logic.vocs.ExtendedSymbolPresentationName;
import com.atsisa.gox.reels.logic.vocs.FreeGamesPresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.response.CommonSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.ExtendedSymbolSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.ExtendedSymbolWinSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.FreeGamesInfoSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.FreeGamesSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.FreeGamesWinSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.GamblerSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.HistorySerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.InitSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.LogicErrorSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.response.TranslationSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.WinSerializationStrategy;
import com.atsisa.gox.reels.message.processing.IGameMessageProcessor;
import com.atsisa.gox.reels.model.ExtendedSymbolLinesModelProvider;
import com.atsisa.gox.reels.model.ExtendedSymbolModelProvider;
import com.atsisa.gox.reels.model.FreeGamesModelProvider;
import com.atsisa.gox.reels.model.IExtendedSymbolModelProvider;
import com.atsisa.gox.reels.model.IFreeGamesModelProvider;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.atsisa.gox.reels.model.ReelGameSoundModel;
import com.atsisa.gox.reels.screen.BaseGameScreen;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.DebugScreen;
import com.atsisa.gox.reels.screen.ErrorScreen;
import com.atsisa.gox.reels.screen.GamblerScreen;
import com.atsisa.gox.reels.screen.HistoryScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.LanguageScreen;
import com.atsisa.gox.reels.screen.WinLinesScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.reels.screen.model.HistoryScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.reels.screen.transition.TopDownInfoScreenTransition;

/**
 * Represents an IoC module configuration.
 */
public class BookOfRaDeluxeCoreModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(BookOfRaDeluxe.class).asEagerSingleton();
        bind(IGame.class).to(BookOfRaDeluxe.class).asEagerSingleton();
        bind(IGameConfiguration.class).toProvider(BookOfRaDeluxeGameConfigurationProvider.class).asEagerSingleton();

        bind(AbstractGame.class).to(BookOfRaDeluxe.class).asEagerSingleton();

        bind(ExtendedSymbolModelProvider.class).asEagerSingleton();
        bind(FreeGamesModelProvider.class).asEagerSingleton();
        bind(DebugBookOfRaDeluxeGameLogic.class).asEagerSingleton();
        bind(IReelGameLogic.class).to(DebugBookOfRaDeluxeGameLogic.class).asEagerSingleton();
        bind(ITranslationProvider.class).to(DebugBookOfRaDeluxeGameLogic.class).asEagerSingleton();

        bind(IResponseSerializationStrategy.class).to(CommonSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(GamblerSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(HistorySerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(TranslationSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(WinSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(InitSerializationStrategy.class).asEagerSingleton();

        bind(IResponseSerializationStrategy.class).to(ExtendedSymbolSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(ExtendedSymbolWinSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(FreeGamesInfoSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(FreeGamesSerializationStrategy.class).asEagerSingleton();
        bind(IResponseSerializationStrategy.class).to(FreeGamesWinSerializationStrategy.class).asEagerSingleton();

        bind(ILinesModelProvider.class).to(ExtendedSymbolLinesModelProvider.class).asEagerSingleton();
        bind(IFreeGamesModelProvider.class).to(FreeGamesModelProvider.class).asEagerSingleton();
        bind(IExtendedSymbolModelProvider.class).to(ExtendedSymbolModelProvider.class).asEagerSingleton();

        bindConstant().named(ExtendedSymbolWinSerializationStrategy.EXTENDED_SYMBOL_WIN_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAME_NEXT);
        bindConstant().named(ExtendedSymbolWinSerializationStrategy.EXTENDED_SYMBOL_WIN_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_WIN);
        bindConstant().named(ExtendedSymbolWinSerializationStrategy.EXTENDED_SYMBOL_WIN_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_RETRIGGER);

        bindConstant().named(ExtendedSymbolSerializationStrategy.EXTENDED_SYMBOL_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_RETRIGGER);
        bindConstant().named(ExtendedSymbolSerializationStrategy.EXTENDED_SYMBOL_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_WIN);
        bindConstant().named(ExtendedSymbolSerializationStrategy.EXTENDED_SYMBOL_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAME_NEXT);

        bindConstant().named(ExtendedSymbolSerializationStrategy.EXTENDED_SYMBOL_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_LIMIT);
        bindConstant().named(ExtendedSymbolWinSerializationStrategy.EXTENDED_SYMBOL_WIN_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_LIMIT);

        bindConstant().named(ExtendedSymbolSerializationStrategy.EXTENDED_SYMBOL_PRESENTATIONS).to(ExtendedSymbolPresentationName.SPECIAL_SCATTER);

        bindConstant().named(CommonSerializationStrategy.COMMON_PRESENTATIONS).to(FreeGamesPresentationName.ENTER_FREE_GAMES);
        bindConstant().named(CommonSerializationStrategy.COMMON_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAME_NEXT);
        bindConstant().named(CommonSerializationStrategy.COMMON_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_WIN);
        bindConstant().named(CommonSerializationStrategy.COMMON_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_RETRIGGER);
        bindConstant().named(CommonSerializationStrategy.COMMON_PRESENTATIONS).to(FreeGamesPresentationName.FREE_GAMES_LIMIT);

        bindConstant().named(CommonSerializationStrategy.COMMON_PRESENTATIONS).to(ExtendedSymbolPresentationName.SPECIAL_SCATTER);

        bindConstant().named(FreeGamesWinSerializationStrategy.FREE_GAMES_WIN_PRESENTATIONS).to(ExtendedSymbolPresentationName.SPECIAL_SCATTER);
        bindConstant().named(FreeGamesSerializationStrategy.FREE_GAMES_PRESENTATIONS).to(ExtendedSymbolPresentationName.SPECIAL_SCATTER);
        bindConstant().named(FreeGamesInfoSerializationStrategy.FREE_GAMES_INFO_PRESENTATIONS).to(ExtendedSymbolPresentationName.SPECIAL_SCATTER);

        bindConstant().named(GamblerScreen.LAYOUT_ID_PROPERTY).to("gamblerScreen");
        bindConstant().named(InfoScreen.LAYOUT_ID_PROPERTY).to("infoScreen");
        bindConstant().named(WinLinesScreen.LAYOUT_ID_PROPERTY).to("winLinesScreen");
        bindConstant().named(BottomPanelScreen.LAYOUT_ID_PROPERTY).to("bottomPanelScreen");
        bindConstant().named(BaseGameScreen.LAYOUT_ID_PROPERTY).to("baseGameScreen");
        bindConstant().named(ErrorScreen.LAYOUT_ID_PROPERTY).to("errorScreen");
        bindConstant().named(DebugScreen.LAYOUT_ID_PROPERTY).to("debugScreen");
        bindConstant().named(LanguageScreen.LAYOUT_ID_PROPERTY).to("languageScreen");
        bindConstant().named(HistoryScreen.LAYOUT_ID_PROPERTY).to("historyScreen");

        bindConstant().named(BookOfRaDeluxeFreeGamesBannerScreen.LAYOUT_ID_PROPERTY).to("freeGamesBannerScreen");
        bindConstant().named(BookOfRaDeluxePayTableScreen.BOOK_OF_RA_DELUXE_PAYTABLE_LAYOUT_ID_PROPERTY).to("payTableScreen");
        bindConstant().named(BookOfRaDeluxeEnterFeatureBannerScreen.LAYOUT_ID_PROPERTY).to("enterFeatureBannerScreen");

        bindConstant().named(ReelGameSoundModel.INFO_SCREEN_SHOW_ANIMATION_SOUND_ID_PROPERTY).to("Shift");
        bindConstant().named(ReelGameSoundModel.AUTO_PLAY_OFF_SOUND_ID_PROPERTY).to("AutoPlayOff");
        bindConstant().named(ReelGameSoundModel.AUTO_PLAY_ON_SOUND_ID_PROPERTY).to("AutoPlayOn");
        bindConstant().named(ReelGameSoundModel.BET_CHANGING_SOUND_ID_PROPERTY).to("BetChanging");

        bindConstant().named(GamblerScreen.HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/small_card_red.png");
        bindConstant().named(GamblerScreen.HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/small_clubs_ace.png");
        bindConstant().named(GamblerScreen.HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/small_diamonds_ace.png");
        bindConstant().named(GamblerScreen.HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/small_hearts_ace.png");
        bindConstant().named(GamblerScreen.HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/small_spades_ace.png");
        bindConstant().named(GamblerScreen.SPADE_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/big_spades_ace.png");
        bindConstant().named(GamblerScreen.CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/big_clubs_ace.png");
        bindConstant().named(GamblerScreen.HEART_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/big_hearts_ace.png");
        bindConstant().named(GamblerScreen.DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/big_diamonds_ace.png");
        bindConstant().named(GamblerScreen.REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/gamblerAtlas/big_card_blue.png");

        bind(HistoryScreenModel.class);
        bind(GamblerScreenModel.class);
        bind(BottomPanelScreenModel.class);
        bind(BookOfRaDeluxePayTableScreenModel.class);
        bind(BookOfRaDeluxeFreeGamesInfoBannerScreenModel.class);
        bind(BookOfRaDeluxeFeatureScreenModel.class);
        bind(InfoScreenTransition.class).to(TopDownInfoScreenTransition.class).asEagerSingleton();

        bind(Screen.class).to(BookOfRaDeluxeEnterFeatureBannerScreen.class).asEagerSingleton();
        bind(Screen.class).to(BookOfRaDeluxeFreeGamesBannerScreen.class).asEagerSingleton();
        bind(Screen.class).to(BookOfRaDeluxeGamblerScreen.class).asEagerSingleton();
        bind(Screen.class).to(BookOfRaDeluxeInfoScreen.class).asEagerSingleton();
        bind(Screen.class).to(BaseGameScreen.class).asEagerSingleton();
        bind(Screen.class).to(BookOfRaDeluxePayTableScreen.class).asEagerSingleton();
        bind(Screen.class).to(BookOfRaDeluxeBottomPanelScreen.class).asEagerSingleton();
        bind(Screen.class).to(LanguageScreen.class).asEagerSingleton();
        bind(Screen.class).to(WinLinesScreen.class).asEagerSingleton();
        bind(Screen.class).to(ErrorScreen.class).asEagerSingleton();
        bind(Screen.class).to(DebugScreen.class).asEagerSingleton();
        bind(Screen.class).to(HistoryScreen.class).asEagerSingleton();

        bind(AbstractReelGameComponents.class).to(DebugBaseReelGameComponents.class).asEagerSingleton();
        bind(AbstractReelGameComponents.class).to(ExtendedSymbolComponents.class).asEagerSingleton();
        bind(IGameMessageProcessor.class).to(BookOfRaFreeGamesMessageProcessor.class).asEagerSingleton();

        bind(IReelsPresentationStates.class).to(FreeGamesPresentationStates.class).asEagerSingleton();
        bind(IReelsPresentationStates.class).to(ExtendedSymbolPresentationStates.class).asEagerSingleton();
    }
}