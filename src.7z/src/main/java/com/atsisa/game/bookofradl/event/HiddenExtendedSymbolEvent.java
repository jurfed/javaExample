package com.atsisa.game.bookofradl.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when extended symbol was hidden.
 */
@Reflectable
public class HiddenExtendedSymbolEvent {

}
