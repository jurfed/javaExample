package com.atsisa.game.bookofradl.screen;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.game.bookofradl.command.HideSelectedExtendedSymbolCommand;
import com.atsisa.game.bookofradl.command.ShowSelectedExtendedSymbolCommand;
import com.atsisa.game.bookofradl.command.StartSelectingExtendedSymbolAnimationCommand;
import com.atsisa.game.bookofradl.command.HighlightSelectedExtendedSymbolCommand;
import com.atsisa.game.bookofradl.event.HiddenExtendedSymbolEvent;
import com.atsisa.game.bookofradl.event.HighlightedExtendedSymbolEvent;
import com.atsisa.game.bookofradl.event.ShownExtendedSymbolEvent;
import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxeFeatureScreenModel;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.IPauseable;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.reels.event.ExtendedSymbolModelChangedEvent;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;
import rx.Subscription;

@Reflectable
public class BookOfRaDeluxeEnterFeatureBannerScreen extends Screen<BookOfRaDeluxeFeatureScreenModel> implements IResetable, IPauseable {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "EnterFeatureBannerScreenLayoutId";

    /**
     * Frame number when book is shown and closed.
     */
    private static final int CLOSED_BOOK_ANIMATION_FRAME = 7;

    /**
     * Last flipping pages frame number
     */
    private static final int LAST_FLIPPING_PAGES_FRAME = 98;

    /**
     * Start closing book animation frame number
     */
    private static final int START_CLOSING_BOOK_ANIMATION_FRAME = 99;

    /**
     * Mapping of symbols frames in a book animation
     */
    private Map<String, Integer> symbolFrames;

    /**
     * Book select extended symbol animation
     */
    @InjectView
    public KeyframeAnimationView selectingExtendedSymbolAnimation;

    /**
     * Book select extended symbol glow animation
     */
    @InjectView
    public KeyframeAnimationView selectingExtendedSymbolGlowAnimation;

    /**
     * Subscription for selecting extended symbol animation
     */
    private Subscription selectingExtendedSymbolAnimationSubscription;

    /**
     * Subscription for selecting extended symbol glow animation
     */
    private Subscription selectingExtendedSymbolGlowAnimationSubscription;

    /**
     * Determines if selecting extended symbol animation was played
     */
    private boolean animationPlayed = false;

    /**
     * Initializes a new instance of the {@link BookOfRaDeluxeEnterFeatureBannerScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link BookOfRaDeluxeFeatureScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public BookOfRaDeluxeEnterFeatureBannerScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, BookOfRaDeluxeFeatureScreenModel model, IRenderer renderer,
            IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        setupSymbolFramesMap();
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new ExtendedSymbolModelChangedEventObserver(), ExtendedSymbolModelChangedEvent.class);
        getEventBus().register(new FreeGamesModelChangedEventObserver(), FreeGamesModelChangedEvent.class);
        getEventBus().register(new StartSelectingExtendedSymbolAnimationCommandObserver(), StartSelectingExtendedSymbolAnimationCommand.class);
        getEventBus().register(new ShowSelectedExtendedSymbolCommandObserver(), ShowSelectedExtendedSymbolCommand.class);
        getEventBus().register(new HideSelectedExtendedSymbolCommandObserver(), HideSelectedExtendedSymbolCommand.class);
        getEventBus().register(new HighlightSelectedExtendedSymbolCommandObserver(), HighlightSelectedExtendedSymbolCommand.class);
    }

    /**
     * Handles the event about free games model was changed.
     * @param event {@link FreeGamesModelChangedEvent}
     */
    @Subscribe
    public void handleFreeGamesModelChangedEvent(FreeGamesModelChangedEvent event) {
        getModel().setTotalFreeGamesNumber(event.getFreeGamesModel().getTotalFreeGamesNumber());
    }

    /**
     * Handles the command that starts the animation of the book.
     * @param startSelectingExtendedSymbolAnimationCommand {@link StartSelectingExtendedSymbolAnimationCommand}
     */
    @Subscribe
    public void handleStartSelectingExtendedSymbolAnimationCommand(StartSelectingExtendedSymbolAnimationCommand startSelectingExtendedSymbolAnimationCommand) {
        startBookScatterAnimation();
    }

    /**
     * Handles the command that animation of the book should be stopped on the selected symbol.
     * @param showSelectedExtendedSymbolCommand {@link ShowSelectedExtendedSymbolCommand}
     */
    @Subscribe
    public void handleShowSelectedExtendedSymbolCommand(ShowSelectedExtendedSymbolCommand showSelectedExtendedSymbolCommand) {
        selectFeatureSpecialScatterSymbol();
    }

    /**
     * Handles the command to highlight selected extended scatter symbol.
     * @param highlightSelectedExtendedSymbolCommand
     */
    public void handleHighlightSelectedExtendedSymbolCommand(HighlightSelectedExtendedSymbolCommand highlightSelectedExtendedSymbolCommand){
        selectingExtendedSymbolGlowAnimationSubscription = selectingExtendedSymbolGlowAnimation.getAnimationStateObservable().subscribe(animationGlowState -> {
            if (animationGlowState == AnimationState.STOPPED) {
                getEventBus().post(new HighlightedExtendedSymbolEvent());
            }
        });
        selectingExtendedSymbolGlowAnimation.play();
    }

    /**
     * Handles the event about extended symbol model was changed.
     * @param extendedSymbolModelChangedEvent {@link ExtendedSymbolModelChangedEvent}
     */
    @Subscribe
    public void handleExtendedSymbolModelChangedEvent(ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
        getModel().setExtendedSymbolName(extendedSymbolModelChangedEvent.getExtendedSymbolModel().getExtendedSymbolName());
    }

    /**
     * Handles the command that book animation should be hidden
     * @param hideSelectedExtendedSymbolCommand {@link HideSelectedExtendedSymbolCommand}
     */
    @Subscribe
    public void handleHideSelectedExtendedSymbolCommand(HideSelectedExtendedSymbolCommand hideSelectedExtendedSymbolCommand) {
        hideFeatureScatterSymbol();
    }

    /**
     * Starts the book animation.
     */
    @ExposeMethod
    public void startBookScatterAnimation() {
        if (!animationPlayed) {
            selectingExtendedSymbolAnimation.setLoop(true);
            selectingExtendedSymbolAnimation.setEndLoopFrameNumber(LAST_FLIPPING_PAGES_FRAME);
            selectingExtendedSymbolAnimation.play();
            animationPlayed = true;
        }
    }

    /**
     * Hides the book animation.
     */
    @ExposeMethod
    public void hideFeatureScatterSymbol() {
        if (selectingExtendedSymbolAnimation != null) {
            clearAnimationSubscription();
            selectingExtendedSymbolAnimation.setEndLoopFrameNumber(0);
            selectingExtendedSymbolAnimation.gotoAndPlay(START_CLOSING_BOOK_ANIMATION_FRAME);
            selectingExtendedSymbolAnimationSubscription = selectingExtendedSymbolAnimation.getAnimationStateObservable().subscribe(animationState -> {
                if (animationState == AnimationState.STOPPED) {
                    this.getEventBus().post(new HiddenExtendedSymbolEvent());
                    reset();
                }
            });
        }
    }

    @Override
    @ExposeMethod
    public void pause() {
        clearAnimationSubscription();
        if (selectingExtendedSymbolAnimation != null && selectingExtendedSymbolAnimation.isPlaying()) {
            selectingExtendedSymbolAnimation.pause();
        }
        if (selectingExtendedSymbolGlowAnimation != null && selectingExtendedSymbolGlowAnimation.isPlaying()) {
            selectingExtendedSymbolGlowAnimation.pause();
        }
    }

    @Override
    @ExposeMethod
    public void reset() {
        clearAnimationSubscription();
        selectingExtendedSymbolAnimation.gotoAndPause(1);
        selectingExtendedSymbolAnimation.setLoop(true);
        selectingExtendedSymbolAnimation.setEndLoopFrameNumber(LAST_FLIPPING_PAGES_FRAME);
        selectingExtendedSymbolGlowAnimation.gotoAndPause(1);
        animationPlayed = false;
    }

    @Override
    protected void notifyScreenShown(Object sourceEvent) {
        super.notifyScreenShown(sourceEvent);
        selectingExtendedSymbolAnimation.playToAndPause(CLOSED_BOOK_ANIMATION_FRAME);
    }

    /**
     * Fills map with symbol name key and animation frame to stop
     */
    private void setupSymbolFramesMap() {
        symbolFrames = new HashMap<>();
        symbolFrames.put("ace", 59);
        symbolFrames.put("king", 67);
        symbolFrames.put("queen", 75);
        symbolFrames.put("jack", 83);
        symbolFrames.put("ten", 91);
        symbolFrames.put("statue", 43);
        symbolFrames.put("person", 27);
        symbolFrames.put("scarab", 51);
        symbolFrames.put("mummy", 35);
    }

    /**
     * Stops the book animation on the selected symbol.
     */
    @ExposeMethod
    public void selectFeatureSpecialScatterSymbol() {
        String symbolName = getModel().getExtendedSymbolName().toLowerCase();
        selectingExtendedSymbolAnimation.setLoop(false);
        selectingExtendedSymbolAnimationSubscription = selectingExtendedSymbolAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                selectingExtendedSymbolAnimation.gotoAndPlay(selectingExtendedSymbolAnimation.getBeginLoopFrameNumber());
                selectingExtendedSymbolAnimation.playToAndPause(symbolFrames.get(symbolName));
            } else if (animationState == AnimationState.PAUSED) {
                getEventBus().post(new ShownExtendedSymbolEvent());
            }
        });
    }
/*
    /**
     * Shows the extended symbol for history purpose.
     */
    @ExposeMethod
    public void forceShowExtendedSymbol() {
        String symbolName = getModel().getExtendedSymbolName().toLowerCase();
        selectingExtendedSymbolAnimation.gotoAndPause(symbolFrames.get(symbolName));
    }

    /**
     * Clears the subscription for the selecting extended symbol animation.
     */
    private void clearAnimationSubscription() {
        if (selectingExtendedSymbolAnimationSubscription != null) {
            selectingExtendedSymbolAnimationSubscription.unsubscribe();
            selectingExtendedSymbolAnimationSubscription = null;
        }
        if ( selectingExtendedSymbolGlowAnimationSubscription != null ){
            selectingExtendedSymbolGlowAnimationSubscription.unsubscribe();
            selectingExtendedSymbolGlowAnimationSubscription = null;
        }
    }

    private class StartSelectingExtendedSymbolAnimationCommandObserver extends NextObserver<StartSelectingExtendedSymbolAnimationCommand> {

        @Override
        public void onNext(StartSelectingExtendedSymbolAnimationCommand startSelectingExtendedSymbolAnimationCommand) {
            handleStartSelectingExtendedSymbolAnimationCommand(startSelectingExtendedSymbolAnimationCommand);
        }
    }

    private class FreeGamesModelChangedEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);
        }
    }

    private class ExtendedSymbolModelChangedEventObserver extends NextObserver<ExtendedSymbolModelChangedEvent> {

        @Override
        public void onNext(ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
            handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);
        }
    }

    private class ShowSelectedExtendedSymbolCommandObserver extends NextObserver<ShowSelectedExtendedSymbolCommand> {

        @Override
        public void onNext(ShowSelectedExtendedSymbolCommand showSelectedExtendedSymbolCommand) {
            handleShowSelectedExtendedSymbolCommand(showSelectedExtendedSymbolCommand);
        }
    }

    private class HideSelectedExtendedSymbolCommandObserver extends NextObserver<HideSelectedExtendedSymbolCommand> {

        @Override
        public void onNext(HideSelectedExtendedSymbolCommand hideSelectedExtendedSymbolCommand) {
            handleHideSelectedExtendedSymbolCommand(hideSelectedExtendedSymbolCommand);
        }
    }

    private class HighlightSelectedExtendedSymbolCommandObserver extends NextObserver<HighlightSelectedExtendedSymbolCommand> {

        @Override
        public void onNext(HighlightSelectedExtendedSymbolCommand highlightSelectedExtendedSymbolCommand) {
            handleHighlightSelectedExtendedSymbolCommand(highlightSelectedExtendedSymbolCommand);

        }
    }

}