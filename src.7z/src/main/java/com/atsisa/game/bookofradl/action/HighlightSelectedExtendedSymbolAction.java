package com.atsisa.game.bookofradl.action;

import com.atsisa.game.bookofradl.command.HighlightSelectedExtendedSymbolCommand;
import com.atsisa.game.bookofradl.event.HighlightedExtendedSymbolEvent;
import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Request for highlight shown feature extended symbol
 */
public class HighlightSelectedExtendedSymbolAction extends WaitForEventAction<HighlightedExtendedSymbolEvent> {

    /**
     * Initializes a new instance of the {@link HighlightSelectedExtendedSymbolAction} class.
     */
    public HighlightSelectedExtendedSymbolAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link HighlightSelectedExtendedSymbolAction} class.
     * @param logger   {@link ILogger} a logger reference
     * @param eventBus {@link IEventBus} a event bus reference
     */
    public HighlightSelectedExtendedSymbolAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new HighlightSelectedExtendedSymbolCommand());
    }

    @Override
    protected Class<HighlightedExtendedSymbolEvent> getEventClass() {
        return HighlightedExtendedSymbolEvent.class;
    }
}