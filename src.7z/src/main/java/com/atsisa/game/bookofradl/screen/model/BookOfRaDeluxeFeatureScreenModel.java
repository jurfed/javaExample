package com.atsisa.game.bookofradl.screen.model;

import com.atsisa.game.bookofradl.screen.BookOfRaDeluxeEnterFeatureBannerScreen;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.google.inject.Inject;


/**
 * Screen model for {@link BookOfRaDeluxeEnterFeatureBannerScreen}. Stores data about total free games number and extended symbol name.
 */
public class BookOfRaDeluxeFeatureScreenModel extends ScreenModel {

    /**
     * Number of all won free games
     */
    private int totalFreeGamesNumber;

    /**
     * Selected extended symbol
     */
    private String selectedExtendedSymbol;

    /**
     * Initializes new instance of {@link BookOfRaDeluxeFeatureScreenModel} class
     * @param translator {@link ITranslator} a translator reference
     */
    @Inject
    public BookOfRaDeluxeFeatureScreenModel(ITranslator translator) {
        super(translator);
    }

    /**
     * Sets total free games number value
     * @param value total free games number
     */
    public void setTotalFreeGamesNumber( int value ){
        totalFreeGamesNumber = value;
    }

    /**
     * Gets total free games number value
     * @return total free games number
     */
    public int getTotalFreeGamesNumber(){
        return totalFreeGamesNumber;
    }

    /**
     * Sets extended symbol name
     * @param value extended symbol name
     */
    public void setExtendedSymbolName( String value ){
        selectedExtendedSymbol = value;
    }

    /**
     * Gets extended symbol name
     * @return extended symbol name
     */
    public String getExtendedSymbolName(){
        return selectedExtendedSymbol;
    }

}