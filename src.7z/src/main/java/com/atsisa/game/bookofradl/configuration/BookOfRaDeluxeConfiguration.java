package com.atsisa.game.bookofradl.configuration;

import java.util.Collections;

import com.atsisa.gox.framework.configuration.GameConfiguration;

/**
 * Book of Ra Deluxe configuration.
 */
public class BookOfRaDeluxeConfiguration extends GameConfiguration {

    /**
     * Initializes a new instance of the {@link BookOfRaDeluxeConfiguration} class.
     */
    public BookOfRaDeluxeConfiguration() {
        this.setResourcePath("BookOfRaDL/");
        this.setWidth(1920);
        this.setHeight(2160);
        this.setWindowDecorated(false);
    }
}
