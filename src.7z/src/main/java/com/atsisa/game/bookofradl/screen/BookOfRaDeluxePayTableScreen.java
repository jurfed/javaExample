package com.atsisa.game.bookofradl.screen;

import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxePayTableScreenModel;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.event.ExtendedSymbolModelChangedEvent;
import com.atsisa.gox.reels.model.IExtendedSymbolModel;
import com.atsisa.gox.reels.model.IPayTableModelItem;
import com.atsisa.gox.reels.screen.PayTableScreen;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Represents the pay table screen for feature and base games.
 */
public class BookOfRaDeluxePayTableScreen extends PayTableScreen {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String BOOK_OF_RA_DELUXE_PAYTABLE_LAYOUT_ID_PROPERTY = "BookOfRaDeluxePayTableScreen";

    /**
     * Pay table feature screen visible.
     */
    private static final String PAY_TABLE_FEATURE_SCREEN_VISIBLE = "payTableFeatureScreenVisible";

    /**
     * Pay table base game screen visible.
     */
    private static final String PAY_TABLE_BASE_GAME_SCREEN_VISIBLE = "payTableBaseGameScreenVisible";

    /**
     * Fourth scatter symbol visible.
     */
    private static final String TWO_SCATTER_PAYS_VISIBLE = "twoScatterPaysVisible";

    /**
     * Inject View of the extended symbol.
     */
    @InjectView
    public ViewGroup extendedSymbolGroup;

    /**
     * Name of the current extended symbol.
     */
    private String extendedSymbolName;

    /**
     * Initializes a new instance of {@link PayTableScreen} class.
     * @param layoutId         the layout identifier
     * @param model            {@link BookOfRaDeluxePayTableScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public BookOfRaDeluxePayTableScreen(@Named(BOOK_OF_RA_DELUXE_PAYTABLE_LAYOUT_ID_PROPERTY) String layoutId, BookOfRaDeluxePayTableScreenModel model,
            IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }

    /**
     * Updates pay table with received scatter amount, updates Scatter symbol on pay table.
     */
    @Subscribe
    public void handleExtendedSymbolModelChangedEvent(ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
        IExtendedSymbolModel extendedSymbolModel = extendedSymbolModelChangedEvent.getExtendedSymbolModel();
        if (extendedSymbolModel != null && extendedSymbolModel.getExtendedSymbolPayTableItems() != null) {
            Iterable<IPayTableModelItem> symbols = extendedSymbolModel.getExtendedSymbolPayTableItems();
            if (Iterables.size(extendedSymbolModel.getExtendedSymbolPayTableItems()) > 3) {
                setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.TRUE);
            } else {
                setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.FALSE);
            }
            ((BookOfRaDeluxePayTableScreenModel) getModel()).updateExtendedSymbols(symbols);
            updateFeatureInfo(extendedSymbolModel.getExtendedSymbolName());
            showFeatureInfo();
        } else {
            hideFeatureInfo();
        }
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        hideFeatureInfo();
    }

    @Override
    protected void registerEvents() {
        getEventBus().register(new ExtendedSymbolModelChangedEventObserver(), ExtendedSymbolModelChangedEvent.class);
        super.registerEvents();
    }

    @Override
    protected void afterActivated() {
        if (!StringUtility.isNullOrEmpty(extendedSymbolName)) {
            updateFeatureInfo(extendedSymbolName);
        } else {
            hideFeatureInfo();
        }
        super.afterActivated();
    }

    /**
     * Shows feature screen.
     */
    private void showFeatureInfo() {
        setModelProperty(PAY_TABLE_BASE_GAME_SCREEN_VISIBLE, Boolean.FALSE);
        setModelProperty(PAY_TABLE_FEATURE_SCREEN_VISIBLE, Boolean.TRUE);
    }

    /**
     * Hides feature screen.
     */
    private void hideFeatureInfo() {
        setModelProperty(PAY_TABLE_BASE_GAME_SCREEN_VISIBLE, Boolean.TRUE);
        setModelProperty(PAY_TABLE_FEATURE_SCREEN_VISIBLE, Boolean.FALSE);
        setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.FALSE);
    }

    /**
     * Updates extended info visibility depending on the extended symbol name.
     * @param extendedSymbolName the extended symbol name.
     */
    private void updateFeatureInfo(String extendedSymbolName) {
        this.extendedSymbolName = extendedSymbolName;
        if (extendedSymbolGroup == null) {
            return;
        }
        for (View view : extendedSymbolGroup.getChildren()) {
            if (view.getId().contains(extendedSymbolName)) {
                view.setVisible(true);
            } else {
                view.setVisible(false);
            }
        }
    }

    private class ExtendedSymbolModelChangedEventObserver extends NextObserver<ExtendedSymbolModelChangedEvent> {

        @Override
        public void onNext(final ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {

            handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);

        }

    }

}

