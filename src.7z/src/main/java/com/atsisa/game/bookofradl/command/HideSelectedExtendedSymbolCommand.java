package com.atsisa.game.bookofradl.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command to hide feature special scatter symbol
 */
@Reflectable
public class HideSelectedExtendedSymbolCommand {

}
