package com.atsisa.game.bookofradl.model;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxePayTableScreenModel;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.reels.logic.model.PayTableItem;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.model.IPayTableModelItem;

/**
 * Tests for {@link BookOfRaDeluxePayTableScreenModel} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class BookOfRaDeluxePayTableScreenModelTest {

    /**
     * Translation mock.
     */
    @Mock
    ITranslator translator;

    /**
     * Configuration provider mock.
     */
    @Mock
    IConfigurationProvider configurationProvider;

    /**
     * Credits formatter mock.
     */
    @Mock
    ICreditsFormatter creditsFormatter;

    /**
     * Pay table screen model for test.
     */
    private BookOfRaDeluxePayTableScreenModel bookOfRaDeluxePayTableScreenModel;

    /**
     * Called before each tests.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        bookOfRaDeluxePayTableScreenModel = new BookOfRaDeluxePayTableScreenModel(translator, configurationProvider, creditsFormatter);

    }

    /**
     * Tests whether the book of ra deluxe screen model properly sorts received value.
     */
    @Test
    public void shouldSortPropertiesCorrectly() {
        //GIVEN
        BigDecimal firstValue = new BigDecimal(7500);
        BigDecimal secondValue = new BigDecimal(2000);
        BigDecimal thirdValue = new BigDecimal(5000);

        IPayTableModelItem firstPayTableItem = mock(IPayTableModelItem.class);
        IPayTableModelItem secondPayTableItem = mock(IPayTableModelItem.class);
        IPayTableModelItem thirdPayTableItem = mock(IPayTableModelItem.class);

        ArrayList<IPayTableModelItem> payTableItems = new ArrayList<>();
        payTableItems.add(firstPayTableItem);
        payTableItems.add(secondPayTableItem);
        payTableItems.add(thirdPayTableItem);

        when(creditsFormatter.format(any(), any())).thenAnswer(new Answer<String>() {

            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                BigDecimal bigDecimal = (BigDecimal) invocation.getArguments()[0];
                if (bigDecimal == firstValue) {
                    return "7500";
                } else if (bigDecimal == secondValue) {
                    return "2000";
                } else if (bigDecimal == thirdValue) {
                    return "5000";
                }
                return null;
            }
        });

        when(firstPayTableItem.getValue()).thenReturn(thirdValue);
        when(secondPayTableItem.getValue()).thenReturn(firstValue);
        when(thirdPayTableItem.getValue()).thenReturn(secondValue);
        when(configurationProvider.getConfiguration()).thenReturn(mock(IConfiguration.class));

        //WHEN
        bookOfRaDeluxePayTableScreenModel.updateExtendedSymbols(payTableItems);

        //THEN
        Assert.assertEquals("7500", bookOfRaDeluxePayTableScreenModel.getProperty("extendedSymbolX5Pays").get());
        Assert.assertEquals("5000", bookOfRaDeluxePayTableScreenModel.getProperty("extendedSymbolX4Pays").get());
        Assert.assertEquals("2000", bookOfRaDeluxePayTableScreenModel.getProperty("extendedSymbolX3Pays").get());

    }

}
