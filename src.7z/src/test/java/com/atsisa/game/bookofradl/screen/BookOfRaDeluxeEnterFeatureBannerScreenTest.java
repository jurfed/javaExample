package com.atsisa.game.bookofradl.screen;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.game.bookofradl.command.ShowSelectedExtendedSymbolCommand;
import com.atsisa.game.bookofradl.command.StartSelectingExtendedSymbolAnimationCommand;
import com.atsisa.game.bookofradl.event.ShownExtendedSymbolEvent;
import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxeFeatureScreenModel;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.ILayout;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.atsisa.gox.reels.model.IFreeGamesModel;

import rx.subjects.PublishSubject;

/**
 * Class containing tests for {@link BookOfRaDeluxeEnterFeatureBannerScreen}
 */
@RunWith(MockitoJUnitRunner.class)
public class BookOfRaDeluxeEnterFeatureBannerScreenTest {

    public static final String LAYOUT_ID_PROPERTY = "EnterFeatureBannerScreenLayoutId";

    /**
     * The layout mock.
     */
    @Mock
    private ILayout layout;

    /**
     * The event bus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * The Book Of Ra Deluxe feature screen model mock.
     */
    @Mock
    private BookOfRaDeluxeFeatureScreenModel model;

    /**
     * The renderer mock.
     */
    @Mock
    private IRenderer renderer;

    /**
     * The view manager mock.
     */
    @Mock
    private IViewManager viewManager;

    /**
     * The animation factory mock.
     */
    @Mock
    private IAnimationFactory animationFactory;

    /**
     * The logger mock.
     */
    @Mock
    private ILogger logger;

    /**
     * Tested provider.
     */
    private BookOfRaDeluxeEnterFeatureBannerScreen featureInfoBannerScreen;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        featureInfoBannerScreen = new BookOfRaDeluxeEnterFeatureBannerScreen(LAYOUT_ID_PROPERTY, model, renderer, viewManager, animationFactory, logger, eventBusMock);
    }

    /**
     * Tests if free games number is properly set in {@link BookOfRaDeluxeFeatureScreenModel}
     */
    @Test
    public void shouldSetTotalFreeGamesNumberWhenEventReceived() {
        //GIVEN
        FreeGamesModelChangedEvent freeGamesModelChangedEvent = mock(FreeGamesModelChangedEvent.class);
        IFreeGamesModel freeGamesModel = mock(IFreeGamesModel.class);
        when(freeGamesModelChangedEvent.getFreeGamesModel()).thenReturn(freeGamesModel);
        when(freeGamesModel.getTotalFreeGamesNumber()).thenReturn(10);

        //WHEN
        featureInfoBannerScreen.handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);

        //THEN
        verify( model ).setTotalFreeGamesNumber( 10 );
    }

    /**
     * Tests if selecting extended symbol animation is played after feature screen is shown
     */
    @Test
    public void shouldStartBookAnimationWhenScreenShown() {
        //GIVEN
        TweenViewAnimation tweenViewAnimation = mock(TweenViewAnimation.class);
        PublishSubject<AnimationState> animationObservable = PublishSubject.create();

        KeyframeAnimationView bookAnimation = mock(KeyframeAnimationView.class);
        featureInfoBannerScreen.selectingExtendedSymbolAnimation = bookAnimation;

        when(tweenViewAnimation.getAnimationStateObservable()).thenReturn(animationObservable);
        when(animationFactory.createAnimation(TweenViewAnimation.class)).thenReturn(tweenViewAnimation);
        when(viewManager.getLayout(LAYOUT_ID_PROPERTY)).thenReturn( layout );
        featureInfoBannerScreen.initialize();

        //WHEN
        featureInfoBannerScreen.show();
        animationObservable.onNext(AnimationState.STOPPED);

        //THEN
        verify( bookAnimation ).playToAndPause(anyInt());
    }

    /**
     * Tests if selecting extended symbol animation is played after dispatching {@link StartSelectingExtendedSymbolAnimationCommand}
     */
    @Test
    public void shouldShowSelectingExtendedSymbolAnimationWhenReqestForThatWillBeDispatched() {
        //GIVEN
        KeyframeAnimationView bookAnimation = mock(KeyframeAnimationView.class);
        featureInfoBannerScreen.selectingExtendedSymbolAnimation = bookAnimation;
        when(viewManager.getLayout(LAYOUT_ID_PROPERTY)).thenReturn( layout );
        featureInfoBannerScreen.initialize();

        //WHEN
        featureInfoBannerScreen.handleStartSelectingExtendedSymbolAnimationCommand( new StartSelectingExtendedSymbolAnimationCommand() );

        //THEN
        verify(bookAnimation).play();
    }

    /**
     * Tests if ShownExtendedSymbolEvent is posted when {@link ShowSelectedExtendedSymbolCommand} is recieved
     */
    @Test
    public void shouldPostShownExtendedSymbolEventWhenShowSelectedExtendedSymbolCommandIsRecieved(){

        //GIVEN
        KeyframeAnimationView bookAnimation = mock(KeyframeAnimationView.class);
        featureInfoBannerScreen.selectingExtendedSymbolAnimation = bookAnimation;
        when(viewManager.getLayout(LAYOUT_ID_PROPERTY)).thenReturn( layout );
        featureInfoBannerScreen.initialize();
        PublishSubject<AnimationState> animationObservable = PublishSubject.create();
        when( bookAnimation.getAnimationStateObservable() ).thenReturn(animationObservable);
        when(model.getExtendedSymbolName()).thenReturn("ten");

        //WHEN
        featureInfoBannerScreen.handleStartSelectingExtendedSymbolAnimationCommand( new StartSelectingExtendedSymbolAnimationCommand() );
        featureInfoBannerScreen.handleShowSelectedExtendedSymbolCommand(new ShowSelectedExtendedSymbolCommand());

        //THEN
        animationObservable.onNext(AnimationState.STOPPED);
        verify( bookAnimation ).gotoAndPlay(anyInt());
        verify( bookAnimation ).playToAndPause(anyInt());

        animationObservable.onNext(AnimationState.PAUSED);
        verify( eventBusMock ).post(any(ShownExtendedSymbolEvent.class));
    }

}