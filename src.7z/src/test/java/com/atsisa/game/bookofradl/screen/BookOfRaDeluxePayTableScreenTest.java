package com.atsisa.game.bookofradl.screen;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.game.bookofradl.screen.model.BookOfRaDeluxePayTableScreenModel;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.event.ExtendedSymbolModelChangedEvent;
import com.atsisa.gox.reels.logic.model.PayTableItem;
import com.atsisa.gox.reels.model.IExtendedSymbolModel;
import com.atsisa.gox.reels.model.IPayTableModelItem;

/**
 * Tests for {@link BookOfRaDeluxePayTableScreen} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class BookOfRaDeluxePayTableScreenTest {

    /**
     * Name of the layout id property.
     */
    public static final String BOOK_OF_RA_DELUXE_PAYTABLE_LAYOUT_ID_PROPERTY = "BookOfRaDeluxePayTableScreen";

    /**
     * The event bus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Pay table screen model mock.
     */
    @Mock
    private BookOfRaDeluxePayTableScreenModel model;

    /**
     * Renderer mock.
     */
    @Mock
    private IRenderer renderer;

    /**
     * View manager mock.
     */
    @Mock
    private IViewManager viewManager;

    /**
     * List of pay table items.
     */
    private List<IPayTableModelItem> symbols;

    /**
     * Animation factory mock.
     */
    @Mock
    private IAnimationFactory animationFactory;

    /**
     * Pay table item mock.
     */
    @Mock
    private IPayTableModelItem firstPayTableItem;

    /**
     * Logger mock.
     */
    @Mock
    private ILogger logger;

    /**
     * Pay table screen instance for test.
     */
    private BookOfRaDeluxePayTableScreen bookOfRaDeluxePayTableScreen;

    /**
     * Sets up mocks and create pay table screen class instance for tests.
     */
    @Before
    public void setUp() {
        symbols = new ArrayList<>();
        MockitoAnnotations.initMocks(this);
        bookOfRaDeluxePayTableScreen = new BookOfRaDeluxePayTableScreen(BOOK_OF_RA_DELUXE_PAYTABLE_LAYOUT_ID_PROPERTY, model, renderer, viewManager,
                animationFactory, logger, eventBusMock);
    }

    /**
     * Tests whether the screen updates screen with data from model.
     */
    @Test
    public void shouldPassInfoAboutPayTableForExtendedSymbolToModelWhenExtendedSymbolModelWillChange() {
        //GIVEN
        ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent = mock(ExtendedSymbolModelChangedEvent.class);
        IExtendedSymbolModel extendedSymbolModel = mock(IExtendedSymbolModel.class);
        when(extendedSymbolModelChangedEvent.getExtendedSymbolModel()).thenReturn(extendedSymbolModel);
        when(extendedSymbolModel.getExtendedSymbolPayTableItems()).thenReturn(symbols);

        when(firstPayTableItem.getValue()).thenReturn(BigDecimal.valueOf(159));
        symbols.add(firstPayTableItem);

        ViewGroup extendedSymbol = mock(ViewGroup.class);

        when(extendedSymbol.getChildren()).thenReturn(new ArrayList<>());
        bookOfRaDeluxePayTableScreen.extendedSymbolGroup = extendedSymbol;

        //WHEN
        bookOfRaDeluxePayTableScreen.handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);

        //THEN
        verify(model).updateExtendedSymbols(symbols);
    }

    /**
     * Tests whether the screen displays proper expanding symbol.
     */

    @Test
    public void shouldDisplayProperExpandingSymbolOnPayTable() {

        //GIVEN
        ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent = mock(ExtendedSymbolModelChangedEvent.class);
        IExtendedSymbolModel extendedSymbolModel = mock(IExtendedSymbolModel.class);
        when(extendedSymbolModelChangedEvent.getExtendedSymbolModel()).thenReturn(extendedSymbolModel);
        when(extendedSymbolModel.getExtendedSymbolName()).thenReturn("Statue");

        when(extendedSymbolModel.getExtendedSymbolPayTableItems()).thenReturn(symbols);
        when(firstPayTableItem.getValue()).thenReturn(BigDecimal.valueOf(159));
        symbols.add(firstPayTableItem);

        ViewGroup extendedSymbol = mock(ViewGroup.class);

        View personSymbol = mock(View.class);
        when(personSymbol.getId()).thenReturn("Person");

        View personBookSymbol = mock(View.class);
        when(personBookSymbol.getId()).thenReturn("PersonBook");

        View mummySymbol = mock(View.class);
        when(mummySymbol.getId()).thenReturn("Mummy");

        View mummyBookSymbol = mock(View.class);
        when(mummyBookSymbol.getId()).thenReturn("MummyBook");

        View statueSymbol = mock(View.class);
        when(statueSymbol.getId()).thenReturn("Statue");

        View statueBookSymbol = mock(View.class);
        when(statueBookSymbol.getId()).thenReturn("StatueBook");

        View scarabSymbol = mock(View.class);
        when(scarabSymbol.getId()).thenReturn("Scarab");

        View scarabBookSymbol = mock(View.class);
        when(scarabBookSymbol.getId()).thenReturn("ScarabBook");

        ArrayList<View> expandingSymbols = new ArrayList<>();
        expandingSymbols.add(personSymbol);
        expandingSymbols.add(personBookSymbol);
        expandingSymbols.add(mummySymbol);
        expandingSymbols.add(mummyBookSymbol);
        expandingSymbols.add(statueSymbol);
        expandingSymbols.add(statueBookSymbol);
        expandingSymbols.add(scarabSymbol);
        expandingSymbols.add(scarabBookSymbol);

        when(extendedSymbol.getChildren()).thenReturn(expandingSymbols);
        bookOfRaDeluxePayTableScreen.extendedSymbolGroup = extendedSymbol;

        //WHEN
        bookOfRaDeluxePayTableScreen.handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);

        //THEN
        verify(personSymbol).setVisible(false);
        verify(personBookSymbol).setVisible(false);
        verify(mummySymbol).setVisible(false);
        verify(mummyBookSymbol).setVisible(false);
        verify(statueSymbol).setVisible(true);
        verify(statueBookSymbol).setVisible(true);
        verify(scarabSymbol).setVisible(false);
        verify(scarabBookSymbol).setVisible(false);

    }

}