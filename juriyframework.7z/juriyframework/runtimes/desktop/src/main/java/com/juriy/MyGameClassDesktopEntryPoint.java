package com.juriy;

import com.atsisa.gox.framework.FrameworkCoreModule;
import com.atsisa.gox.framework.FrameworkDesktopModule;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.inject.AggregatedModule;
import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.inject.IModule;

public class MyGameClassDesktopEntryPoint extends JavaGameEntryPoint {

    public static void main(String[] args) throws Exception {
        new MyGameClassDesktopEntryPoint().start();
        IActionManager manager = GameEngine.current().getActionManager();

    }

    @Override
    protected IModule getModule() {
        return new AggregatedModule(
        new FrameworkCoreModule(),
        new FrameworkDesktopModule(),
        new MyGameClassCoreModule());
    }
}
