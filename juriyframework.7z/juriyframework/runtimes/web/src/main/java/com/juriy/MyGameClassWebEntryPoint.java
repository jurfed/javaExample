package com.juriy;

import com.atsisa.gox.framework.HtmlGameEntryPoint;

public class MyGameClassWebEntryPoint extends HtmlGameEntryPoint {

    private static final String GAME_NAME = "MyGameClass";

    @Override
    protected String getGameName() {
        return GAME_NAME;
    }

}
