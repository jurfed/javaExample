package com.juriy;

import com.atsisa.gox.framework.AbstractGame;
import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.inject.AbstractModule;
import com.juriy.configuration.MyGameClassConfiguration;
import com.juriy.screen.MainScreen;

/**
 * Represents an IoC module configuration.
 */
public class MyGameClassCoreModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(MyGameClass.class).asEagerSingleton();
        bind(IGame.class).to(MyGameClass.class).asEagerSingleton();
        bind(AbstractGame.class).to(MyGameClass.class).asEagerSingleton();
        bind(IGameConfiguration.class).to(MyGameClassConfiguration.class).asEagerSingleton();

        bindConstant().named(MainScreen.LAYOUT_ID).to("mainscreen");

        bind(Screen.class).to(MainScreen.class).asEagerSingleton();
    }
}
