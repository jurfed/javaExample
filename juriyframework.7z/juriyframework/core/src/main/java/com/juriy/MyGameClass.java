package com.juriy;

import com.atsisa.gox.framework.AbstractGame;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.*;

import java.util.ArrayList;
import java.util.List;

public class MyGameClass extends AbstractGame {

    @Override
    public void onStart() {

        getEngine().getViewManager().getScreenById("mainscreen").show();

    }
}
