package com.atsisa.game.bookofradl;

import com.atsisa.gox.reels.BaseReelGameComponents;
import com.atsisa.gox.reels.DebugAbstractReelGame;
import com.atsisa.gox.reels.DebugBaseReelGameComponents;
import com.google.inject.Inject;

public class BookOfRaDeluxe extends DebugAbstractReelGame {

    /**
     * Initializes a new instance of the {@link BookOfRaDeluxe} class.
     * @param baseReelGameComponents {@link BaseReelGameComponents}
     */
    @Inject
    public BookOfRaDeluxe(BaseReelGameComponents baseReelGameComponents) {
        super(baseReelGameComponents);
    }

}
