package com.atsisa.game.bookofradl.provider;

import com.atsisa.game.bookofradl.configuration.BookOfRaDeluxeConfiguration;
import com.atsisa.gox.framework.configuration.DisplayResolutionType;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.google.inject.Provider;

public class BookOfRaDeluxeGameConfigurationProvider implements Provider<IGameConfiguration> {

    /**
     * Game configuration instance.
     */
    private static IGameConfiguration instance;

    @Override
    public IGameConfiguration get() {
        if (instance == null) {
            instance = new BookOfRaDeluxeConfiguration();
        }
        return instance;
    }





}