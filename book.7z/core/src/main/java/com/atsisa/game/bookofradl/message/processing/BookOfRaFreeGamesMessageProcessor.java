package com.atsisa.game.bookofradl.message.processing;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.atsisa.gox.reels.message.GameMessage;
import com.atsisa.gox.reels.message.processing.IGameMessageProcessor;
import com.google.inject.Inject;

/**
 * Adjusts messages during free games according to received translations.
 */
public class BookOfRaFreeGamesMessageProcessor implements IGameMessageProcessor {

    /**
     * Free game message.
     */
    private static final String FREE_GAME_MESSAGE = "{#LangFreeGame}";

    /**
     * Of message.
     */
    private static final String OF_MESSAGE = "{#LangOf}";

    /**
     * Number of current free game.
     */
    private int currentFreeGameNumber;

    /**
     * Total number of free games.
     */
    private int totalFreeGamesNumber;

    /**
     * The eventBus.
     */
    private final IEventBus eventBus;

    /**
     * Initializes a new instance of the {@link BookOfRaFreeGamesMessageProcessor} class.
     */
    @Inject
    public BookOfRaFreeGamesMessageProcessor(IEventBus eventBus) {
        this.eventBus = eventBus;
        registerEvents();
    }

    @Override
    public void process(GameMessage gameMessage) {
        StringBuilder sb = new StringBuilder(FREE_GAME_MESSAGE);
        sb.append(" - ");
        sb.append(OF_MESSAGE);
        if (gameMessage.getContent().equals(sb.toString())) {
            String newMessage = StringUtility.format("%s %s %s %s", FREE_GAME_MESSAGE, currentFreeGameNumber, OF_MESSAGE,
                    totalFreeGamesNumber);
            gameMessage.setContent(newMessage);
        }
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new FreeGamesEventObserver(), FreeGamesModelChangedEvent.class);
    }

    /**
     * Updates free games model after change.
     * @param freeGamesModelChangedEvent {@link FreeGamesModelChangedEvent}
     */
    private void handleFreeGamesModelChanged(FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
        currentFreeGameNumber = freeGamesModelChangedEvent.getFreeGamesModel().getCurrentFreeGameNumber();
        totalFreeGamesNumber = freeGamesModelChangedEvent.getFreeGamesModel().getTotalFreeGamesNumber();
    }

    private class FreeGamesEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            handleFreeGamesModelChanged(freeGamesModelChangedEvent);
        }
    }
}