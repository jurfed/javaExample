package com.atsisa.game.bookofradl.action;

import com.atsisa.game.bookofradl.command.StartSelectingExtendedSymbolAnimationCommand;
import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Request for start feature extended symbol animation
 */
public class StartSelectingExtendedSymbolAnimationAction extends SyncAction {

    /**
     * Initializes a new instance of the {@link StartSelectingExtendedSymbolAnimationAction} class.
     */
    public StartSelectingExtendedSymbolAnimationAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link StartSelectingExtendedSymbolAnimationAction} class.
     * @param logger {@link ILogger} a logger reference
     * @param eventBus {@link IEventBus} a event bus reference
     */
    public StartSelectingExtendedSymbolAnimationAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new StartSelectingExtendedSymbolAnimationCommand() );
    }

}