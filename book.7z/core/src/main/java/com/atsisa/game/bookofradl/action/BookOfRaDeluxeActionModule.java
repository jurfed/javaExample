package com.atsisa.game.bookofradl.action;

import com.atsisa.gox.framework.action.AbstractActionModule;

/**
 * Action module for Book Of Ra Deluxe
 */
public class BookOfRaDeluxeActionModule extends AbstractActionModule {

    /**
     * Book Of Ra Deluxe actions module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/game/bookofradl/action";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerAction("StartSelectingExtendedSymbolAnimation", StartSelectingExtendedSymbolAnimationAction.class);
        registerAction("ShowSelectedExtendedSymbol", ShowSelectedExtendedSymbolAction.class);
        registerAction("HideSelectedExtendedSymbol", HideSelectedExtendedSymbolAction.class);
        registerAction("HighlightSelectedExtendedSymbol", HighlightSelectedExtendedSymbolAction.class );
    }

}