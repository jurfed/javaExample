package com.atsisa.game.bookofradl;

import com.atsisa.gox.framework.HtmlGameEntryPoint;

public class BookOfRaDeluxeWebEntryPoint extends HtmlGameEntryPoint {

    private static final String GAME_NAME = "BookOfRaDeluxe";

    @Override
    protected String getGameName() {
        return GAME_NAME;
    }

}
