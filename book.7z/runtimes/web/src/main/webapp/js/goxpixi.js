(function () {

    function GoxText(text) {
        PIXI.Text.call(this, text);
    }

    GoxText.prototype = Object.create(PIXI.Text.prototype);
    GoxText.prototype.constructor = PIXI.Text;

    PIXI.GoxText = GoxText;

    GoxText.prototype.isNewLine = function (char) {
        return /(?:\r\n|\r|\n)/.test(char);
    };

    GoxText.prototype.wordWrap = function (text) {
        var result = '';
        var wordWrapWidth = this._style.wordWrapWidth;

        var spaceLeft = wordWrapWidth;
        var word = "";
        for (var i = 0; i < text.length; ++i) {
            var char = text.charAt(i);
            if (this.isNewLine(char)) {
                result += "\n";
                spaceLeft = wordWrapWidth;
                continue;
            }
            word += char;
            if (char == " " || i + 1 == text.length || text.charAt(i + 1) == " " || this.isNewLine(text.charAt(i + 1))) {
                var wordWidth = this.context.measureText(word).width * this.scale.x;
                if (wordWidth < spaceLeft) {
                    result += word;
                    spaceLeft -= wordWidth;
                } else {
                    if (spaceLeft < wordWrapWidth) {
                        result += "\n";
                        spaceLeft = wordWrapWidth;
                    }
                    for (var j = 0; j < word.length; ++j) {
                        var singleChar = word.charAt(j);
                        var characterWidth = this.context.measureText(singleChar).width * this.scale.x;
                        if (characterWidth > spaceLeft) {
                            result += '\n' + singleChar;
                            spaceLeft = wordWrapWidth - characterWidth;
                        } else {
                            result += singleChar;
                            spaceLeft -= characterWidth;
                        }
                    }
                }
                word = "";
            }
        }
        return result;
    };

    function GoxBitmapText(text, style) {
        PIXI.extras.BitmapText.call(this, text, style ? {} : style);
    }

    GoxBitmapText.prototype = Object.create(PIXI.extras.BitmapText.prototype);
    GoxBitmapText.prototype.constructor = PIXI.extras.BitmapText;

    PIXI.GoxBitmapText = GoxBitmapText;

    GoxBitmapText.prototype.isNewLine = function (char) {
        return /(?:\r\n|\r|\n)/.test(char);
    };

    GoxBitmapText.prototype.updateText = function () {
        var data = PIXI.extras.BitmapText.fonts[this._font.name];
        if (data == null || this.text == null) {
            return;
        }
        var pos = new PIXI.Point();
        var prevCharCode = null;
        var chars = [];
        var lastLineWidth = 0;
        var maxLineWidth = 0;
        var lineWidths = [];
        var line = 0;
        var scale = this._font.size / data.size;
        var maxLineHeight = 0;

        for (var i = 0; i < this.text.length; i++) {
            var charCode = this.text.charCodeAt(i);
            if (this.isNewLine(this.text.charAt(i))) {
                pos.x = 0;
                pos.y += data.lineHeight;
                prevCharCode = null;
                continue;
            }
            var charData = data.chars[charCode];
            if (!charData) {
                continue;
            }
            if (prevCharCode && charData.kerning[prevCharCode]) {
                pos.x += charData.kerning[prevCharCode];
            }
            var widthChar = charData.texture.width != 0 ? charData.texture.width : charData.xAdvance;
            chars.push({
                charData: charData,
                width: widthChar,
                texture: charData.texture,
                char: this.text.charAt(i),
                charCode: charCode,
                position: new PIXI.Point(pos.x + charData.xOffset, pos.y + charData.yOffset)
            });
            pos.x += charData.xAdvance;
            maxLineHeight = Math.max(maxLineHeight, (charData.yOffset + charData.texture.height));
            prevCharCode = charCode;
        }

        if (this.maxWidth > 0) {
            var maxWidth = this.maxWidth * (data.size / this._font.size) * (1 / this.scale.x);
            var wordArr = [];
            var width = 0;
            pos.x = 0;
            pos.y = 0;
            var newLinesCount;
            for (var i = 0; i < chars.length; ++i) {
                if (wordArr.length == 0) {
                    pos.x = chars[i].position.x;
                }
                wordArr.push(chars[i]);
                if (i + 1 == chars.length || chars[i].char == " " || chars[i + 1].char == " ") {
                    if (wordArr.length > 0) {
                        var len = wordArr.length;
                        width = ((wordArr[len - 1].position.x + wordArr[len - 1].width) - wordArr[0].position.x);
                        if (width + pos.x > maxWidth) {
                            if (wordArr[0].position.x == wordArr[0].charData.xOffset) {
                                newLinesCount = 0;
                            } else {
                                newLinesCount = 1;
                            }
                            pos.x = 0;
                            for (var j = 0; j < wordArr.length; ++j) {
                                wordArr[j].position.y += data.lineHeight * newLinesCount;
                                wordArr[j].position.x = pos.x + wordArr[j].charData.xOffset;
                                pos.x += wordArr[j].charData.xAdvance;
                                lastPosX = pos.x;
                                if (j + 1 < wordArr.length && pos.x + wordArr[j + 1].width > maxWidth) {
                                    pos.x = 0;
                                    newLinesCount++;
                                }
                            }

                            if (i + 1 < chars.length) {
                                var updateX = true;
                                for (var j = i + 1; j < chars.length; ++j) {
                                    if (chars[j].position.x == chars[j].charData.xOffset) {
                                        updateX = false;
                                    }
                                    if (updateX) {
                                        chars[j].position.x = pos.x;
                                        pos.x += chars[j].charData.xAdvance;
                                    }
                                    chars[j].position.y += data.lineHeight * newLinesCount;
                                }
                            }
                        }
                        width = 0;
                    }
                    wordArr = [];
                }
            }
        }

        for (var i = 0; i < chars.length; ++i) {
            if (i != 0 && chars[i].position.x == chars[i].charData.xOffset) {
                lineWidths.push(lastLineWidth);
                lastLineWidth = 0;
                line++;
            }
            chars[i].line = line;
            lastLineWidth = chars[i].position.x + chars[i].texture.width;
            maxLineWidth = Math.max(maxLineWidth, lastLineWidth);
        }
        lineWidths.push(lastLineWidth);
        maxLineWidth = Math.max(maxLineWidth, lastLineWidth);

        var lineAlignOffsets = [];

        for (i = 0; i <= line; i++) {
            var alignOffset = 0;

            if (this._font.align === 'right') {
                alignOffset = maxLineWidth - lineWidths[i];
            } else if (this._font.align === 'center') {
                alignOffset = (maxLineWidth - lineWidths[i]) / 2;
            }

            lineAlignOffsets.push(alignOffset);
        }

        var lenChars = chars.length;
        var tint = this.tint;

        for (i = 0; i < lenChars; i++) {
            var c = this._glyphs[i]; // get the next glyph sprite

            if (c) {
                c.texture = chars[i].texture;
            } else {
                c = new PIXI.Sprite(chars[i].texture);
                this._glyphs.push(c);
            }

            c.position.x = (chars[i].position.x + lineAlignOffsets[chars[i].line]) * scale;
            c.position.y = chars[i].position.y * scale;
            c.scale.x = c.scale.y = scale;
            c.tint = tint;
            if (!c.parent) {
                this.addChild(c);
            }
        }

        for (i = lenChars; i < this._glyphs.length; ++i) {
            this.removeChild(this._glyphs[i]);
        }
        this.textWidth = maxLineWidth * scale;
        this.textHeight = ((line + 1) * data.lineHeight) * scale;
        this.maxLineHeight = maxLineHeight * scale;
    };

    function GoxSprite(texture) {
        PIXI.Sprite.call(this, texture);
        this._vertexDataModifiers = Array.apply(null, Array(8)).map(Number.prototype.valueOf, 0);
    }

    GoxSprite.prototype = Object.create(PIXI.Sprite.prototype);
    GoxSprite.prototype.constructor = PIXI.Sprite;

    PIXI.GoxSprite = GoxSprite;

    Object.defineProperties(GoxSprite.prototype, {
        vertexDataModifiers: {
            get: function () {
                return this._vertexDataModifiers;
            }, set: function (value) {
                this._vertexDataModifiers = value;
                this._calculateBounds();
            }
        }
    });

    GoxSprite.prototype.reset = function () {
        this.destroy(false);
        var TransformClass = PIXI.settings.TRANSFORM_MODE === PIXI.TRANSFORM_MODE.STATIC ? PIXI.TransformStatic : PIXI.Transform;
        this.transform = new TransformClass();
        this._texture = PIXI.Texture.EMPTY;
        this._anchor = new PIXI.ObservablePoint(this._onAnchorUpdate, this);
        this.filters = null;
        this.alpha = 1;
        this.wordAlpha = 1;
        this.visible = true;
        this._bounds = new PIXI.Bounds();
        this.width = 0;
        this.height = 0;
        this.tint = 0xFFFFFF;
        this.cachedTint = 0xFFFFFF;
        this.vertexData = new Float32Array(8);
        this.vertexTrimmedData = null;
        this._textureID = -1;
        this._transformID = -1;
        this.blendMode = PIXI.BLEND_MODES.NORMAL;
    }

    GoxSprite.prototype.calculateVertices = function () {
        if (this._transformID === this.transform._worldID && this._textureID === this._texture._updateID) {
            return;
        }

        this._transformID = this.transform._worldID;
        this._textureID = this._texture._updateID;

        // set the vertex data

        var texture = this._texture, wt = this.transform.worldTransform, a = wt.a, b = wt.b, c = wt.c, d = wt.d, tx = wt.tx, ty = wt.ty, vertexData = this.vertexData, w0, w1, h0, h1, trim = texture.trim, orig = texture.orig;

        if (trim) {
            // if the sprite is trimmed and is not a tilingsprite then we need to add the extra space before transforming the sprite coords..
            w1 = trim.x - this.anchor._x * orig.width;
            w0 = w1 + trim.width;

            h1 = trim.y - this.anchor._y * orig.height;
            h0 = h1 + trim.height;

        } else {
            w0 = orig.width * (1 - this.anchor._x);
            w1 = orig.width * -this.anchor._x;

            h0 = orig.height * (1 - this.anchor._y);
            h1 = orig.height * -this.anchor._y;
        }

        // xy
        vertexData[0] = a * w1 + c * h1 + tx + this._vertexDataModifiers[0];
        vertexData[1] = d * h1 + b * w1 + ty + this._vertexDataModifiers[1];

        // xy
        vertexData[2] = a * w0 + c * h1 + tx + this._vertexDataModifiers[2];
        vertexData[3] = d * h1 + b * w0 + ty + this._vertexDataModifiers[3];

        // xy
        vertexData[4] = a * w0 + c * h0 + tx + this._vertexDataModifiers[4];
        vertexData[5] = d * h0 + b * w0 + ty + this._vertexDataModifiers[5];

        // xy
        vertexData[6] = a * w1 + c * h0 + tx + this._vertexDataModifiers[6];
        vertexData[7] = d * h0 + b * w1 + ty + this._vertexDataModifiers[7];
    };

    GoxSprite.prototype.calculateTrimmedVertices = function () {
        if (!this.vertexTrimmedData) {
            this.vertexTrimmedData = new Float32Array(8);
        }

        // lets do some special trim code!
        var texture = this._texture, vertexData = this.vertexTrimmedData, orig = texture.orig;

        // lets calculate the new untrimmed bounds..
        var wt = this.transform.worldTransform, a = wt.a, b = wt.b, c = wt.c, d = wt.d, tx = wt.tx, ty = wt.ty, w0, w1, h0, h1;

        w0 = (orig.width ) * (1 - this.anchor._x);
        w1 = (orig.width ) * -this.anchor._x;

        h0 = orig.height * (1 - this.anchor._y);
        h1 = orig.height * -this.anchor._y;

        // xy
        vertexData[0] = a * w1 + c * h1 + tx + this._vertexDataModifiers[0];
        vertexData[1] = d * h1 + b * w1 + ty + this._vertexDataModifiers[1];

        // xy
        vertexData[2] = a * w0 + c * h1 + tx + this._vertexDataModifiers[2];
        vertexData[3] = d * h1 + b * w0 + ty + this._vertexDataModifiers[3];

        // xy
        vertexData[4] = a * w0 + c * h0 + tx + this._vertexDataModifiers[4];
        vertexData[5] = d * h0 + b * w0 + ty + this._vertexDataModifiers[5];

        // xy
        vertexData[6] = a * w1 + c * h0 + tx + this._vertexDataModifiers[6];
        vertexData[7] = d * h0 + b * w1 + ty + this._vertexDataModifiers[7];
    };

})();