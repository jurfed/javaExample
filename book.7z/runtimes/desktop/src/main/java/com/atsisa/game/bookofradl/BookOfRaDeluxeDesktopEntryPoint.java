package com.atsisa.game.bookofradl;

import com.atsisa.gox.framework.FrameworkCoreModule;
import com.atsisa.gox.framework.FrameworkDesktopModule;
import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.framework.SystemParametersConfigurationModule;
import com.atsisa.gox.inject.AggregatedModule;
import com.atsisa.gox.inject.IModule;
import com.atsisa.gox.reels.DebugReelsCoreModule;
import com.atsisa.gox.reels.ReelsCoreModule;

/**
 * Entry point for desktop version of the game.
 */
public class BookOfRaDeluxeDesktopEntryPoint extends JavaGameEntryPoint {

    /**
     * Entry point.
     * @param args initialize arguments
     * @throws Exception throws when an error occurs during startup
     */
    public static void main(String[] args) throws Exception {
        new BookOfRaDeluxeDesktopEntryPoint().start();
    }

    @Override
    protected IModule getModule() {
        return new AggregatedModule(
            new FrameworkCoreModule(),
            new FrameworkDesktopModule(),
            new ReelsCoreModule(),
            new DebugReelsCoreModule(),
            new BookOfRaDeluxeCoreModule(),
            new SystemParametersConfigurationModule()
        );
    }
}
